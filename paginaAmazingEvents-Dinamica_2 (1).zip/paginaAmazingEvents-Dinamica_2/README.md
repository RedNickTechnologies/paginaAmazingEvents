# paginaAmazingEvents
 pagina a la cual se le agregaran funcionalidades javascript
